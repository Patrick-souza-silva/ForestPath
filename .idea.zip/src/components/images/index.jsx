import React, {useState} from "react";
import { View, FlatList, SafeAreaView, StyleSheet, Image, Dimensions } from "react-native";
import { styles } from "./styles";

function Img(props){


    return(
        <View style={styles.viewImage}>

        </View>

    )
}
export default Img
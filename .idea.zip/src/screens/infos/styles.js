import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    imageInfo: {
        flex: 1,
        alignItems: "center",
        padding:20
      },
})
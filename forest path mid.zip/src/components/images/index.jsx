import React, {useState} from "react";
import { View, FlatList, SafeAreaView, StyleSheet, Image, Dimensions, ImageBackground } from "react-native";
import { styles } from "./styles";

function Img(props){


    return(
        <ImageBackground style={styles.viewImage}>

        </ImageBackground>

    )
}
export default Img
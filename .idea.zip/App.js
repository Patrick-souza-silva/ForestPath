import React from 'react';
import { Routes } from './src/Routes';
import Button from './src/components/flatList';


export default function App() {
  return (
  <Routes></Routes>
  )
}
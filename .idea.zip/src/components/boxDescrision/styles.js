import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    boxDes:{
        width:'100%',
        height:300,
        backgroundColor:"rgba(154, 178, 169, 0.5)",
        borderRadius:10
    }
})
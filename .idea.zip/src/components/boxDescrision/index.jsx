import { View } from "react-native";
import { styles } from "./styles";

function Descricao(props){
    return(
        <View styles={styles.boxDes}>

        </View>
    )
}
export default Descricao